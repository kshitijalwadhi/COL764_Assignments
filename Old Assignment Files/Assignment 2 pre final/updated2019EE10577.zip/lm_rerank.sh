#!/bin/bash
python3 lm.py $1 $2 $3 $4 $5 $6