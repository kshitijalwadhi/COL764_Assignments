#!/bin/bash
python3 rocchio.py $1 $2 $3 $4